Itemset by Pchovancik
http://code.google.com/u/pchovancik/
